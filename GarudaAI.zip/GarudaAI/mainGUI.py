import sys
from PySide2.QtCore import QThread, Signal, Qt
from PySide2 import QtWidgets
from PySide2.QtGui import QIcon
from datetime import datetime
import psutil
from garudaGUI import garudaGUI
from functools import partial
import time
from backend import garudaMain
from func.SpeakOffline import muteGaruda
from func.SpeakOffline import Speak
from func.Listen import Listen
from func.iot import updateSwitch

# Global Variables
current_icon = "play"
garudaSpeakToggle = True
garudaListenToggle = False
sideToggle = False

# Define a worker class for backend operations
class BackendWorker(QThread):
    # finished = Signal()  # Signal emitted when the background task is finished
    update_text = Signal(str)  # Signal to update text in UI

    def __init__(self, message, ui):
        super().__init__()
        self.message = message
        self.ui = ui

    def run(self):
        try:
            if self.message is not None:
                if "bye" in self.message or "quit" in self.message or "exit" in self.message:
                    Speak("Have a Good day Sir")
                    QtWidgets.QApplication.quit()
                else:
                    # Call the backend function
                    response = garudaMain(self.message)

                    # If Error occured comment below 2 lines
                    oldMsgs = self.ui.chatMessages.toHtml()
                    self.update_text.emit(f"{oldMsgs}<div style='color: lightblue; font-weight: 600;'>Garuda: {response}</div><br>")

                    # And uncomment below line
                    # self.update_text.emit(f"<div style='color: lightblue; font-weight: 600;'>Garuda: {response}</div><br>")
                    Speak(response)
        except Exception as e:
            pass
        
class ListenWorker(QThread):
    query_received = Signal(str, str)  # Signal emitted when a query is received

    def __init__(self, ui):
        super().__init__()
        self.ui = ui

    def run(self):
        while True:
            # Simulate listening
            try:
                user_query = Listen()
                if user_query is not None:
                    if "bye" in user_query or "quit" in user_query or "exit" in user_query:
                        Speak("Have a Good day Sir")
                        QtWidgets.QApplication.quit()
                    else:
                        # Speak(response)
                        # Emit signal for the received query
                        response = garudaMain(user_query)
                        self.query_received.emit(user_query, response)
                        Speak(response)
            except Exception as e:
                pass

#Radio buttons
class ToggleSwitchWorker(QThread):
    def __init__(self, switch_id, state):
        super().__init__()
        self.switch_id = switch_id
        self.state = state

    def run(self):
        updateSwitch(self.switch_id, self.state)

# For time
class TimeThread(QThread):
    # Signal to update time, date, and AM/PM
    update_time = Signal(str, str, str, str)

    def run(self):
        while True:
            current_time = datetime.now()
            hours = current_time.strftime("%I")  # 12-hour format
            minutes = current_time.strftime("%M")
            am_pm = current_time.strftime("%p")
            date = current_time.strftime("%a, %d %b")
            self.update_time.emit(hours, minutes, am_pm, date)
            self.sleep(1)

#For system info
class SystemInfoThread(QThread):
    # Signal to update CPU, Memory, and Storage
    update_system_info = Signal(str, str, str)

    def run(self):
        while True:
            cpu_usage = f":  {psutil.cpu_percent()}%"
            memory_info = psutil.virtual_memory()
            memory_usage = f":  {memory_info.percent}%"
            storage_info = psutil.disk_usage('/')
            storage_usage = f":  {storage_info.percent}%"
            self.update_system_info.emit(
                cpu_usage, memory_usage, storage_usage)
            self.sleep(1)

#Returns uptime
class UptimeThread(QThread):
    update_uptime = Signal(int)  # Signal to update uptime

    def run(self):
        uptime = 0
        while True:
            self.update_uptime.emit(uptime)
            uptime += 1
            time.sleep(1)

#Main Program
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = garudaGUI()
        self.ui.setupUi(self)

        # Connect the sendButton click event to the send_message function
        self.ui.sendButton.clicked.connect(self.send_message)

        # Create and start the time update thread
        self.time_thread = TimeThread()
        self.time_thread.update_time.connect(self.update_time_display)
        self.time_thread.start()

        # To hide User Conversation at start-up
        self.ui.chatDisplay.hide()

        # To Set Notification
        self.ui.showNotification.setText("")

        # Create and start the system info update thread
        self.system_info_thread = SystemInfoThread()
        self.system_info_thread.update_system_info.connect(self.update_system_info_display)
        self.system_info_thread.start()

        # Create and start the uptime update thread
        self.uptime_thread = UptimeThread()
        self.uptime_thread.update_uptime.connect(self.update_uptime_display)
        self.uptime_thread.start()

        # Play/Pause Button
        self.ui.pause.clicked.connect(partial(self.music_buttons_menu, "pause"))

        # IOT Switches
        self.ui.IOTSwitch1.clicked.connect(partial(self.toggleSwitch, "v1"))
        self.ui.IOTSwitch2.clicked.connect(partial(self.toggleSwitch, "v2"))

        # For Speak Radio Button
        self.ui.speakSwitch.clicked.connect(partial(self.toggleSpeak))
        self.ui.speakSwitch.setChecked(True)

        # Listening Switch
        self.ui.listenSwitch.clicked.connect(partial(self.toggleListen, "toggle"))

        # Next/Prev Button
        self.ui.nextButton.clicked.connect(partial(self.music_buttons_menu, "next"))
        self.ui.prevButton.clicked.connect(partial(self.music_buttons_menu, "prev"))

        # For Sidebar
        self.ui.sidebarToggle.clicked.connect(partial(self.sidebarToggleGUI))
        self.ui.chatMessages.setHtml("")  # Default Message

        # ListenWorker
        self.listen_worker = None

    def sidebarToggleGUI(self):
        global sideToggle

        if sideToggle:
            self.ui.chatDisplay.hide()
            sideToggle = False
        else:
            self.ui.chatDisplay.show()
            sideToggle = True

    def toggleSpeak(self):
        global garudaSpeakToggle
        oldMsgs = self.ui.chatMessages.toHtml()

        if garudaSpeakToggle:
            muteGaruda(garudaSpeakToggle)
            garudaSpeakToggle = False
            print("Muting Audio")
            self.ui.chatMessages.setHtml(oldMsgs+"<div style='color: lightblue; font-weight: 600;'>Garuda: "+"Muting Audio</div><br>")
        else:
            muteGaruda(garudaSpeakToggle)
            garudaSpeakToggle = True
            print("Unmuting Audio")
            self.ui.chatMessages.setHtml(oldMsgs+"<div style='color: lightblue; font-weight: 600;'>Garuda: "+"Unmuting Audio</div><br>")

    def toggleListen(self, tog):
        global garudaListenToggle

        if not garudaListenToggle:
            garudaListenToggle = True
            print("Listening Audio")

            # Create and start the listening worker thread
            self.listen_worker = ListenWorker(self.ui)
            self.listen_worker.query_received.connect(self.handle_query_received)
            self.listen_worker.start()
        else:
            garudaListenToggle = False
            print("Not Listening Audio")

            # Stop the listening worker thread
            if self.listen_worker:
                self.listen_worker.terminate()
                self.listen_worker = None

    def toggleSwitch(self, sw):
        if sw == 'v1':
            state = "on" if self.ui.IOTSwitch1.isChecked() else "off"
            self.switch_worker_1 = ToggleSwitchWorker(sw, state)
            self.switch_worker_1.start()

        if sw == 'v2':
            state = "on" if self.ui.IOTSwitch2.isChecked() else "off"
            self.switch_worker_2 = ToggleSwitchWorker(sw, state)
            self.switch_worker_2.start()

    def handle_query_received(self, query, response):
        print("Query received:", query)
        if query != "":
            oldMsgs = self.ui.chatMessages.toHtml()
            self.ui.chatMessages.setHtml(f"{oldMsgs}<div align='right' style='color: lightgreen; font-weight: 600;'>User: {query}</div><br>")
            # response = garudaMain(query)
            # Display the response in the GUI before speaking it
            oldMsgs = self.ui.chatMessages.toHtml()
            self.ui.chatMessages.setHtml(f"{oldMsgs}<div align='left' style='color: lightblue; font-weight: 600;'>Garuda: {response}</div><br>")
            # Speak(response)

    def send_message(self):
        # Retrieve the message from the inputTextBox
        message = self.ui.inputTextBox.toPlainText()
        print("Message:", message)

        # Get old conversation from user and append to it.
        oldMsgs = self.ui.chatMessages.toHtml()
        self.ui.chatMessages.setHtml(f"{oldMsgs}<div align='right' style='color: lightgreen; font-weight: 600;'>User: {message}</div><br>")

        self.ui.inputTextBox.setPlainText("")

        # Create a backend worker object
        self.backend_worker = BackendWorker(message, self.ui)

        # Connect signals
        self.backend_worker.update_text.connect(self.update_chat_display)
        # self.backend_worker.finished.connect(self.handle_backend_finished)

        # Start the worker in a separate thread
        self.backend_worker.start()

    def update_chat_display(self, text):
        self.ui.chatMessages.setHtml(text)

    def handle_backend_finished(self):
        # Handle UI updates or cleanup after the backend task is finished
        pass
        # print("Backend task finished")

    def music_buttons_menu(self, btn):
        global current_icon

        if btn == "prev" and current_icon == "pause":
            print(btn)
            garudaMain("previous")
        elif btn == "next" and current_icon == "pause":
            print(btn)
            garudaMain("next")
        elif current_icon == "play":
            # Switch to pause icon
            self.ui.pause.setIcon(QIcon(r"C:\Users\DELL\Desktop\Garuda\Flask GUI\design\imgs\pause.ico"))
            print(current_icon)
            garudaMain("play music")
            current_icon = "pause"
        elif btn == "pause" and current_icon == "pause":
            # Switch to play icon
            self.ui.pause.setIcon(QIcon(r"C:\Users\DELL\Desktop\Garuda\Flask GUI\design\imgs\play.ico"))
            print(current_icon)
            garudaMain("stop")
            current_icon = "play"

    def update_time_display(self, hours, minutes, am_pm, date):
        self.ui.hours.setText(hours)
        self.ui.minutes.setText(minutes)
        self.ui.AM_PM.setText(am_pm)
        self.ui.date.setText(date)

    def update_system_info_display(self, cpu_usage, memory_usage, storage_usage):
        self.ui.cpuValue.setText(cpu_usage)
        self.ui.memoryValue.setText(memory_usage)
        self.ui.storageValue.setText(storage_usage)

    def update_uptime_display(self, uptime):
        self.ui.uptimeValue.setText(f":  {uptime} secs")


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())