import json
import pyautogui

# Load browser shortcuts from JSON file
with open('SHORTCUTS.TXT', 'r') as file:
    shortcuts = json.load(file)["shortcuts"]

# Function to perform shortcut action
def perform_shortcut(action):
    keys = shortcuts.get(action)
    if keys:
        pyautogui.hotkey(*keys.split('+'))
        print(f"Performed shortcut: {keys}")
    else:
        print("Shortcut not found.")

def handle_query(query):
    for action, keys in shortcuts.items():
        if all(word.lower() in query for word in action.lower().split(" ")):
            perform_shortcut(action)
            return

    print("Query not recognized.")

# Testing
# user_query = input("Enter your query: ").lower()
# handle_query(user_query)