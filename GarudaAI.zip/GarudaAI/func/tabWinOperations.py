import pyautogui
# import pygetwindow as gw

try:
    from func.SpeakOffline import Speak
except:
    from SpeakOffline import Speak

keywords = ["switch", "change", "goto", "next",
    "previous", "maximize", "minimize", "minimise", "current", "all"]

def tabWinManipulator(query):
    if "tab" in query and (word for word in query if word in keywords):
        if "previous" in query:
            pyautogui.hotkey('ctrl', 'fn', 'pageup')
            Speak("Switched to previous tab")
        else:
            pyautogui.hotkey('ctrl', 'fn', 'pagedown')
            Speak("Switched to next tab")
    elif "window" in query and (word for word in query if word in keywords):
        if "previous" in query:
            pyautogui.hotkey('alt', 'shift', 'tab')
            Speak("Switched to previous window")
        elif "minimise" in query:
            pyautogui.hotkey('winleft', 'down')
            pyautogui.hotkey('winleft', 'down')
            Speak("Minimised window")
        else:
            pyautogui.hotkey('alt', 'tab')
            Speak("Switched to next window")