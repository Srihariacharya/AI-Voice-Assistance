import json
import datetime

def data_log(user_input, ai_response, isknown=True, Accuracy=0, AI=2):
    timestamp = datetime.datetime.now().isoformat()
    
    log_entry = {
        "Timestamp": timestamp,
        "Data": "Known" if isknown else "Unknown",
        "User": user_input,
        "Garuda": ai_response,
        "AI": AI,
        "Accuracy": Accuracy
    }
    
    with open("Logs/data_log.json", "a") as log_file:
        json.dump(log_entry, log_file)
        log_file.write('\n')

# Test
# user_input = "Hello"
# ai_response = "Yes"
# data_log(user_input, ai_response)