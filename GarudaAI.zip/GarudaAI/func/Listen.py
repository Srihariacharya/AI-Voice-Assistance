import speech_recognition as sr
from plyer import notification

recognizer = sr.Recognizer()

recognizer.pause_threshold = 2


def notifyUser(msg, utimeout=1):
    notification.notify(
        title="Garuda Virtual Assistant",
        message=msg,
        timeout=utimeout,
    )

def Listen() -> str | None:
    with sr.Microphone() as source:
        notifyUser("Listening...")
        print("Listening...")

        recognizer.adjust_for_ambient_noise(source)

        try:
            audio_data = recognizer.listen(
                source, timeout=5, phrase_time_limit=10)
        except Exception as e:
            # print(e)
            pass

        try:
            print("Recognizing...")
            # notifyUser("Recognizing...")

            text = recognizer.recognize_google(audio_data)
            print(f"Speech recognized : {text}")
            # notifyUser(f"Speech recognized : {text}")
            return text
        except sr.UnknownValueError:
            print("Could not understand the audio")
            # notifyUser("Could not understand the audio")
            return None
        except sr.RequestError as e:
            print(f"Error: {e}")
            # notifyUser(f"Error: {e}")
            return None
        except Exception as e:
            print(e)
            # notifyUser(e)
            return None

# recognized_text = Listen()