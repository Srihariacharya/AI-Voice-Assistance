import requests
import random

def get_indian_news():
    # URL to fetch top headlines
    url = 'https://newsapi.org/v2/top-headlines'
    
    # API key
    api_key = 'YOUR-API-KEY'
    
    # Parameters for the request
    parameters = {
        'country': 'in',  # Country code for India
        'apiKey': api_key
    }
    
    # Making a request to the NewsAPI
    response = requests.get(url, params=parameters)
    
    # Checking the status of the request
    if response.status_code == 200:
        # Parsing the response
        data = response.json()
        
        # Extracting articles
        articles = data['articles']
        
        # Shuffling the articles
        random.shuffle(articles)
        
        # Formatting the output
        news_updates = "Here are the latest news updates:<br><br>"
        for i, article in enumerate(articles[:5], start=1):
            news_updates += f"{i}. {article['title']}<br>"
        
        return news_updates
    else:
        return f"Failed to fetch news: {response.status_code}"

# Fetch and display the news
# news = get_indian_news()
# print(news)