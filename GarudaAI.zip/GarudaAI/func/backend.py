# User Library
from Listen import Listen
from SpeakOffline import Speak
# from func.DataOffline import OfflineData
from DataOnline import OnlineScrapper
from youtubeSearch import searchYT
from tabWinOperations import tabWinManipulator as twm
from programmerJoke import tellJoke
from browserOperations import handle_query
from music import music_main
from chatAI import converationAI
import webbrowser
import pygetwindow as gw
from datetime import datetime

# tabWinSwitching keywords
tabkeywords = ["switch", "change", "goto", "next",
    "previous", "maximize", "minimize", "minimise", "current", "all"]

# Online Platform keywords
onlinePlatforms = ["google", "stack overflow", "facebook", "instagram", "twitter", "linkedin",
    "reddit", "pinterest", "youtube", "twitch", "github", "snapchat", "whatsapp", "discord", "chatgpt"]

#Browsers list
browsers = ["brave", "microsoft edge", "google chrome"]

#Music keywords
musicKeywords = ["play", "stop", "previous", "next"]

#Variables
ismusicplay = False

#Get current active window
def currentWindow():
    active_window = gw.getActiveWindow().title
    crnt_window = active_window.split("-")
    crnt_window = crnt_window[len(crnt_window)-1].strip()
    return crnt_window.lower()

#Greet user
def greet_user():
    current_hour = datetime.now().hour
    
    if current_hour < 12:
        greet = "Good Morning"
    elif 12 <= current_hour < 18:
        greet = "Good Afternoon"
    else:
        greet = "Good Evening"
    
    greeting = greet+" Sir! I'm Garuda, your virtual AI assistant. How can I assist you today?"
    return greeting

#Actions function
def actions(userQuery):
    global ismusicplay

    if "play music" in userQuery or "play song" in userQuery:
        ismusicplay = True
    if "search" in userQuery and "youtube" in userQuery:
        searchYT(userQuery)
        return True 
    
    elif (word for word in userQuery if word in tabkeywords) and ("tab" in userQuery or "window" in userQuery):
        twm(userQuery)
        return True
    
    elif (word for word in userQuery if word in onlinePlatforms) and ("open" in userQuery):
        for platform in onlinePlatforms:
            if platform in userQuery:
                webbrowser.open(f"https://www.{platform.replace(' ', '')}.com")
                Speak(f"Opening {platform}")
                return True
            
    elif ("tell" in userQuery or "another") and "joke" in userQuery:
        joke = tellJoke()
        Speak(joke)
        return True

    if "stop" in userQuery and ismusicplay:
        ismusicplay = False
        print("Stopping Music")
        music_main("stop")
        return True
    
    elif(ismusicplay == True) and (word for word in userQuery if word in musicKeywords):
        for word in userQuery.split():
            if word in musicKeywords:
                print(word)
                music_main(word)
                return True
            
    elif ismusicplay:
        music_main("play")

    else:
        return None
    
    return True

#Main
def garudaMain(userQuery):
    global ismusicplay

    # userQuery = Listen()
    activeWindow = currentWindow()

    if userQuery != None:
        userQuery = userQuery.lower()

        if "bye" in userQuery or "quit" in userQuery or "exit" in userQuery:
            Speak("Have a Good day Sir")
            exit()
        elif actions(userQuery) != None:
            print("hello meow meow")
        elif activeWindow in browsers:
            handle_query(userQuery)
        else:
            # getChat = OfflineData(userQuery)
            getChat = converationAI(userQuery)
            getData = OnlineScrapper(userQuery, True)
            if getData != None:
                Speak(getData)
            else:
                if getChat != None:
                    Speak(getChat)
                else:
                    Speak("Try again, Sir")

# Speak(greet_user())
# garudaMain("a program in Python creating a web page")