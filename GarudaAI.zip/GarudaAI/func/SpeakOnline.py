import pygame
from gtts import gTTS

pygame.mixer.init()

GOnlineMute = False

def speak_online(*args, slow=False):
    if GOnlineMute:
        return

    text = ""
    for i in args:
        text += str(i)

    print(text)
    tts = gTTS(text=text, slow=slow)
    tts.save("output.mp3")
    pygame.mixer.music.load("output.mp3")
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(1)  # Adjust the playback speed

def mute_garuda_online(mute):
    global GOnlineMute
    GOnlineMute = mute

# Example usage
# speak_online("नमस्ते, यह गरुड़ा है")  # Hindi
# speak_online("ಹಲೋ, ಇದು ಗರುಡ")  # Kannada
# HELLO ADITHYA