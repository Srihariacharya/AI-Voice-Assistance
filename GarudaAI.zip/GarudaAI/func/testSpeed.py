import speedtest # type: ignore

def downloadSpeed():
  wifi = speedtest.Speedtest()
  download_net = wifi.download()/1048576
  print("Wifi download speed is ", round(download_net, 2), "Mb/s")
  return f"Wifi download speed is {round(download_net, 2)} Mb/s"


def uploadSpeed():
  wifi = speedtest.Speedtest()
  upload_net = wifi.upload()/1048576
  print("Wifi Upload Speed is", round(upload_net, 2))
  return f"Wifi Upload Speed is {round(upload_net, 2)} Mb/s"