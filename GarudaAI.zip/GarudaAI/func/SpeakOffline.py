import pyttsx3

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('rate', 180)
engine.setProperty('volume', 1) #volume
engine.setProperty('voice', voices[0].id) #change voice [change 0 to 1, 2]

GMute=False

# def Speak(*args, **kwargs):
def Speak(*args):
    audio = ""
    for i in args:
        audio += str(i)
        
    audio = audio.replace('<br>', '')

    print(audio)

    if not GMute:
        engine.say(audio)
        engine.runAndWait()

def muteGaruda(mGaruda):
    global GMute
    GMute=mGaruda

# Speak("Hello, This is Garuda <br>")