import pyjokes

def tellJoke():
    joke = pyjokes.get_joke()
    return joke