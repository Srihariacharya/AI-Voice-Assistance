#Greets users
#Added functionality for converting Speech to Text and vise-versa
#Capable of communicating with users
#Trained AI with 75k+ data with neural network and machine learning
#Added Log for every user input
#Added library OnlineScrapper to fetch online data
#Capable of arithmetic calculations
#Added YouTube search functionality
#Switch tab and window
#Play, pause, next, previous, stop music
#Open/close specified apps
#Open various online platforms
#Speed test
#Can generate email, leave letter, story, essay, poem
#Can recommened various tourist places to visit
#Conversational AI
#Latest news updates [Both stocks and current affair news]
#Added IoT Functionality [Can turn on virtual switch]
#Can Generate programing codes
#Has both chat and Voice reponse


## Under Construction [Future updates]
# Extract text from image
# Face Recognition
# Extract text from pdf
# Flask for user interactivity
# Image recognition
# Extract text from pdf and image and work as ebook reader