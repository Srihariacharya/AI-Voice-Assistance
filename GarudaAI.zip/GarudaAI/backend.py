# User Defined Library
from func.Listen import Listen
from func.SpeakOffline import Speak, muteGaruda
# from func.DataOffline import OfflineData
from func.DataOnline import OnlineScrapper
from func.youtubeSearch import searchYT
from func.tabWinOperations import tabWinManipulator as twm
from func.programmerJoke import tellJoke
from func.browserOperations import handle_query
from func.music import music_main
from func.chatAI import converationAI
from func.iot import updateSwitch
from func.testSpeed import downloadSpeed
from func.newsUpdate import get_indian_news
from func.stockNews import get_indian_stock_news

# System Library
import webbrowser
import pygetwindow as gw  # type: ignore
from datetime import datetime
from AppOpener import open, close  # type: ignore

# IOT Switch Keywords
iot_control_keywords = [
    "switch 1 on", "switch 1 off",
    "switch 2 on", "switch 2 off",
    "turn on switch 1", "turn off switch 1",
    "turn on switch 2", "turn off switch 2",
    "activate switch 1", "deactivate switch 1",
    "activate switch 2", "deactivate switch 2",
    "switch A on", "switch A off",
    "switch B on", "switch B off",
    "turn on switch A", "turn off switch A",
    "turn on switch B", "turn off switch B",
    "activate switch A", "deactivate switch A",
    "activate switch B", "deactivate switch B"
]

# News keywords
news_keywords = [
    "latest news", "breaking news",
    "current news", "news update",
    "recent news", "today's news",
    "top news", "headline news",
    "news headlines", "trending news",
    "news now", "news today",
    "latest updates", "recent updates",
    "news report", "news bulletin",
    "latest stories", "current updates",
    "latest headlines", "news flash",
    "current headlines", "top stories",
    "news roundup", "news summary",
    "news highlights", "fresh news",
    "hot news", "live news",
    "news briefing", "up-to-the-minute news",
    "daily news", "news alerts",
    "local news", "international news",
    "national news", "global news",
    "news scoop", "breaking headlines"
]

# Stock News Keywords
stock_news_keyword = [
    "stock news", "stock updates",
    "market news", "market updates",
]

# tabWinSwitching keywords
tabkeywords = ["switch", "change", "goto", "next",
               "previous", "maximize", "minimize", "minimise", "current", "all"]

# Online Platform keywords
onlinePlatforms = ["google", "stack overflow", "facebook", "instagram", "twitter", "linkedin",
                   "reddit", "pinterest", "youtube", "twitch", "github", "snapchat", "whatsapp",
                   "discord", "chatgpt", "quora", "wikipedia"]

# Browsers list
browsers = ["brave", "microsoft edge", "google chrome"]

# Music keywords
musicKeywords = ["play", "stop", "previous", "next"]

# Variables
ismusicplay = False
isSpeak = True

# Get current active window


def currentWindow():
    active_window = gw.getActiveWindow().title
    crnt_window = active_window.split("-")
    crnt_window = crnt_window[len(crnt_window)-1].strip()
    return crnt_window.lower()

# Greet user
def greet_user():
    current_hour = datetime.now().hour

    if current_hour < 12:
        greet = "Good Morning"
    elif 12 <= current_hour < 18:
        greet = "Good Afternoon"
    else:
        greet = "Good Evening"

    greeting = greet+" Sir! I'm Garuda, your virtual AI assistant. How can I assist you today?"
    return greeting

# Actions function
def actions(userQuery):
    global ismusicplay

    if "play music" in userQuery or "play song" in userQuery:
        ismusicplay = True
    if "search" in userQuery and "youtube" in userQuery:
        return (searchYT(userQuery))
        # return True
    elif (word for word in userQuery if word in tabkeywords) and ("tab" in userQuery or "window" in userQuery):
        twm(userQuery)
        return True
    elif ("open" in userQuery or "close" in userQuery) and ("app" in userQuery):
        appName = userQuery.replace("app", "").replace(
            "open", "").replace("close", "")
        if "open" in userQuery:
            open(appName, match_closest=True, output=False)
            # Speak(f"Opening {appName}")
            return (f"Opening {appName}")
        elif "close" in userQuery:
            try:
                close(appName, match_closest=True, output=False)
                # Speak(f"Closing {appName}")
                return (f"Closing {appName}")
            except Exception as e:
                return f"{appName} is not supported for closing"
    elif (word for word in userQuery if word in stock_news_keyword) and ("news" in userQuery) and ("stock" in userQuery or "market" in userQuery):
        return (get_indian_stock_news())
    elif (word for word in userQuery if word in news_keywords) and ("news" in userQuery):
        return (get_indian_news())
    elif (word for word in userQuery if word in onlinePlatforms) and ("open" in userQuery):
        for platform in onlinePlatforms:
            if platform in userQuery:
                webbrowser.open(f"https://www.{platform.replace(' ', '')}.com")
                return (f"Opening {platform}")
    elif ("tell" in userQuery or "another" in userQuery) and "joke" in userQuery:
        joke = tellJoke()
        # Speak(joke)
        return (joke)
        # return True
    elif "mute garuda" in userQuery:
        muteGaruda(True)
        print("mute is working")
    elif "speed test" in userQuery or "check speed" in userQuery:
        Speak("Checking Internet Speed, It may take 10 seconds")
        return (downloadSpeed())
    elif "unmute garuda" in userQuery:
        muteGaruda(False)
        print("unmute is working")
    elif (word for word in userQuery if word in iot_control_keywords):
        if ("A" in userQuery or "1" in userQuery) and "switch" in userQuery:
            if ("on" in userQuery or "activate" in userQuery):
                updateSwitch('v1', "on")
            elif ("off" in userQuery or "deactivate" in userQuery):
                updateSwitch('v1', "off")
            return True
        elif ("B" in userQuery or "2" in userQuery) and "switch" in userQuery:
            if ("on" in userQuery or "activate" in userQuery):
                updateSwitch('v2', "on")
            elif ("off" in userQuery or "deactivate" in userQuery):
                updateSwitch('v2', "off")
            return True

    if "stop" in userQuery and ismusicplay:
        ismusicplay = False
        print("Stopping Music")
        music_main("stop")
        return True
    elif (ismusicplay == True) and (word for word in userQuery if word in musicKeywords):
        for word in userQuery.split():
            if word in musicKeywords:
                print(word)
                return (music_main(word))
                # return True
    elif ismusicplay:
        music_main("play")

    return None

# Main


def garudaMain(userQuery, SpeakGaruda=True):
    global ismusicplay

    # userQuery = Listen()
    activeWindow = currentWindow()

    if userQuery != None:
        userQuery = userQuery.lower()

        action = actions(userQuery)

        if "bye" in userQuery or "quit" in userQuery or "exit" in userQuery:
            Speak("Have a Good day Sir")
            return ("Have a Good day Sir")
            exit()
        elif action != None:
            # print("Action Executed!")
            return (action)
            # return ("Done")
        elif activeWindow in browsers:
            handle_query(userQuery)
        else:
            # getChat = OfflineData(userQuery)
            getChat = converationAI(userQuery)
            getData = OnlineScrapper(userQuery, True)
            if getData != None:
                # Speak(getData)
                print(getData)
                return (getData)
            else:
                if getChat != None:
                    # Speak(getChat)
                    return (getChat)
                else:
                    # Speak("Try again, Sir")
                    return ("Try again, Sir")

# Speak(greet_user())
# print(garudaMain("Hello Garuda"))
