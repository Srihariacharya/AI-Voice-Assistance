# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'garudaGUIazbBea.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class garudaGUI(object):
    def setupUi(self, garudaGUI):
        if not garudaGUI.objectName():
            garudaGUI.setObjectName(u"garudaGUI")
        garudaGUI.setEnabled(True)
        garudaGUI.resize(1024, 720)
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(garudaGUI.sizePolicy().hasHeightForWidth())
        garudaGUI.setSizePolicy(sizePolicy)
        garudaGUI.setMaximumSize(QSize(1024, 720))
        icon = QIcon()
        icon.addFile(u"../../Flask GUI/design/imgs/bg.png", QSize(), QIcon.Normal, QIcon.Off)
        garudaGUI.setWindowIcon(icon)
        garudaGUI.setStyleSheet(u"")
        garudaGUI.setIconSize(QSize(22, 22))
        garudaGUI.setAnimated(False)
        self.garudaContainer = QWidget(garudaGUI)
        self.garudaContainer.setObjectName(u"garudaContainer")
        self.garudaContainer.setStyleSheet(u"QWidget#garudaContainer{\n"
"	background-color: #000;\n"
"}")
        self.systemInfo = QWidget(self.garudaContainer)
        self.systemInfo.setObjectName(u"systemInfo")
        self.systemInfo.setGeometry(QRect(10, 90, 251, 141))
        self.systemInfo.setStyleSheet(u"QWidget#systemInfo{\n"
"	background-color: transparent;\n"
"	border: 2px ridge #00f48e;\n"
"	border-radius: 10px;\n"
"}")
        self.point1 = QLabel(self.systemInfo)
        self.point1.setObjectName(u"point1")
        self.point1.setGeometry(QRect(10, 78, 17, 17))
        self.point1.setStyleSheet(u"background-color: #00f48e;\n"
"border-radius: 2px;")
        self.point3 = QLabel(self.systemInfo)
        self.point3.setObjectName(u"point3")
        self.point3.setGeometry(QRect(10, 106, 17, 17))
        self.point3.setStyleSheet(u"background-color: #00f48e;\n"
"border-radius: 2px;")
        self.memoryName.setAlignment(Qt.AlignCenter)
        self.storageName = QLabel(self.systemInfo)
        self.storageName.setObjectName(u"storageName")
        self.storageName.setGeometry(QRect(45, 98, 91, 31))
        self.storageName.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.storageName.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.cpuValue = QLabel(self.systemInfo)
        self.cpuValue.setObjectName(u"cpuValue")
        self.cpuValue.setGeometry(QRect(100, 16, 121, 21))
        self.cpuValue.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.cpuValue.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.uptimeValue = QLabel(self.systemInfo)
        self.uptimeValue.setObjectName(u"uptimeValue")
        self.uptimeValue.setGeometry(QRect(130, 45, 121, 21))
        self.uptimeValue.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.uptimeValue.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.memoryValue = QLabel(self.systemInfo)
        self.memoryValue.setObjectName(u"memoryValue")
        self.memoryValue.setGeometry(QRect(140, 75, 91, 20))
        self.memoryValue.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.memoryValue.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.storageValue = QLabel(self.systemInfo)
        self.storageValue.setObjectName(u"storageValue")
        self.storageValue.setGeometry(QRect(140, 104, 91, 20))
        self.storageValue.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.storageValue.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.point1_2 = QLabel(self.systemInfo)
        self.point1_2.setObjectName(u"point1_2")
        self.point1_2.setGeometry(QRect(10, 49, 17, 17))
        self.point1_2.setStyleSheet(u"background-color: #00f48e;\n"
"border-radius: 2px;")
        self.point1_3 = QLabel(self.systemInfo)
        self.point1_3.setObjectName(u"point1_3")
        self.point1_3.setGeometry(QRect(10, 20, 17, 17))
        self.point1_3.setStyleSheet(u"background-color: #00f48e;\n"
"border-radius: 2px;")
        self.cpuName = QLabel(self.systemInfo)
        self.cpuName.setObjectName(u"cpuName")
        self.cpuName.setGeometry(QRect(40, 17, 51, 21))
        self.cpuName.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.cpuName.setAlignment(Qt.AlignCenter)
        self.inputTextBox = QPlainTextEdit(self.garudaContainer)
        self.inputTextBox.setObjectName(u"inputTextBox")
        self.inputTextBox.setGeometry(QRect(10, 640, 910, 72))
        font = QFont()
        self.inputTextBox.setFont(font)
        self.inputTextBox.setAutoFillBackground(False)
        self.inputTextBox.setStyleSheet(u"background-color: #fff;\n"
"border-radius: 5px;\n"
"font-size: 30px;")
        self.inputTextBox.setBackgroundVisible(True)
        self.inputTextBox.setPlaceholderText(u"Message Garuda")
        self.timeAndDate = QWidget(self.garudaContainer)
        self.timeAndDate.setObjectName(u"timeAndDate")
        self.timeAndDate.setGeometry(QRect(820, 90, 191, 101))
        self.timeAndDate.setStyleSheet(u"QWidget#timeAndDate{\n"
"background-color: transparent;\n"
"border: 2px ridge #00f48e;\n"
"border-radius: 10px;\n"
"}")
        self.colon = QLabel(self.timeAndDate)
        self.colon.setObjectName(u"colon")
        self.colon.setGeometry(QRect(71, 6, 21, 41))
        self.colon.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-weight: 800;\n"
"font-size: 48px;")
        self.date = QLabel(self.timeAndDate)
        self.date.setObjectName(u"date")
        self.date.setGeometry(QRect(31, 60, 131, 31))
        self.date.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-weight: 800;\n"
"font-size: 20px;")
        self.hours = QLabel(self.timeAndDate)
        self.hours.setObjectName(u"hours")
        self.hours.setGeometry(QRect(10, 10, 51, 41))
        self.hours.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-weight: 800;\n"
"font-size: 40px;")
        self.minutes = QLabel(self.timeAndDate)
        self.minutes.setObjectName(u"minutes")
        self.minutes.setGeometry(QRect(93, 10, 51, 41))
        self.minutes.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-weight: 800;\n"
"font-size: 40px;")
        self.AM_PM = QLabel(self.timeAndDate)
        self.AM_PM.setObjectName(u"AM_PM")
        self.AM_PM.setGeometry(QRect(149, 27, 31, 21))
        self.AM_PM.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-weight: 800;\n"
"font-size: 20px;")
        self.sendButton = QPushButton(self.garudaContainer)
        self.sendButton.setObjectName(u"sendButton")
        self.sendButton.setGeometry(QRect(943, 640, 72, 72))
        self.sendButton.setCursor(QCursor(Qt.PointingHandCursor))
        self.sendButton.setStyleSheet(u"background-color: #fff;\n"
"border-radius: 10px;\n"
"")
        icon1 = QIcon()
        icon1.addFile(u"../../Flask GUI/design/imgs/send.ico", QSize(), QIcon.Normal, QIcon.Off)
        self.sendButton.setIcon(icon1)
        self.sendButton.setIconSize(QSize(34, 34))
        self.Logo = QLabel(self.garudaContainer)
        self.Logo.setObjectName(u"Logo")
        self.Logo.setGeometry(QRect(340, 193, 343, 333))
        self.Logo.setStyleSheet(u"background-color: transparent;\n"
"")
        self.Logo.setFrameShape(QFrame.NoFrame)
        self.Logo.setPixmap(QPixmap(u"../../Flask GUI/design/imgs/bg.png"))
        self.Logo.setScaledContents(True)
        self.Logo.setAlignment(Qt.AlignCenter)
        self.onlineStatus = QLabel(self.garudaContainer)
        self.onlineStatus.setObjectName(u"onlineStatus")
        self.onlineStatus.setGeometry(QRect(20, 600, 171, 20))
        self.onlineStatus.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-weight: 800;\n"
"font-size: 20px;")
        self.musicContainer.setObjectName(u"musicContainer")
        self.musicContainer.setGeometry(QRect(760, 560, 254, 62))
        self.musicContainer.setStyleSheet(u"background-color: transparent; \n"
"border: 2px solid #00f48e;\n"
"border-radius: 10px;\n"
"")
        self.prevButton = QPushButton(self.musicContainer)
        self.prevButton.setObjectName(u"prevButton")
        self.prevButton.setGeometry(QRect(10, 10, 66, 42))
        self.prevButton.setCursor(QCursor(Qt.PointingHandCursor))
        self.prevButton.setStyleSheet(u"background-color: transparent;\n"
"border-radius: 10px;\n"
"border: none;\n"
"")
        icon2 = QIcon()
        icon2.addFile(u"../../Flask GUI/design/imgs/prev.ico", QSize(), QIcon.Normal, QIcon.Off)
        self.prevButton.setIcon(icon2)
        self.prevButton.setIconSize(QSize(48, 48))
        self.nextButton = QPushButton(self.musicContainer)
        self.nextButton.setObjectName(u"nextButton")
        self.nextButton.setGeometry(QRect(180, 10, 66, 42))
        self.nextButton.setCursor(QCursor(Qt.PointingHandCursor))
        self.nextButton.setStyleSheet(u"background-color: transparent;\n"
"border-radius: 10px;\n"
"border: none;\n"
"")
        icon3 = QIcon()
        icon3.addFile(u"../../Flask GUI/design/imgs/next.ico", QSize(), QIcon.Normal, QIcon.Off)
        self.nextButton.setIcon(icon3)
        self.nextButton.setIconSize(QSize(48, 48))
        self.pause = QPushButton(self.musicContainer)
        self.pause.setObjectName(u"pause")
        self.pause.setGeometry(QRect(110, 10, 45, 42))
        self.pause.setCursor(QCursor(Qt.PointingHandCursor))
        self.pause.setStyleSheet(u"background-color: transparent;\n"
"border-radius: 10px;\n"
"border: none;\n"
"")
        icon4 = QIcon()
        icon4.addFile(u"../../Flask GUI/design/imgs/play.ico", QSize(), QIcon.Normal, QIcon.Off)
        icon4.addFile(u"../../Flask GUI/design/imgs/pause.ico", QSize(), QIcon.Normal, QIcon.On)
        icon4.addFile(u"../../Flask GUI/design/imgs/pause.ico", QSize(), QIcon.Active, QIcon.On)
        self.pause.setIcon(icon4)
        self.pause.setIconSize(QSize(48, 48))
        self.navbar = QWidget(self.garudaContainer)
        self.navbar.setObjectName(u"navbar")
        self.navbar.setGeometry(QRect(0, 0, 1024, 78))
        self.navbar.setStyleSheet(u"background-color: #cb6ce6;\n"
"/*border-bottom-right-radius: 10px;*/")
        self.sidebarToggle = QPushButton(self.navbar)
        self.sidebarToggle.setObjectName(u"sidebarToggle")
        self.sidebarToggle.setGeometry(QRect(10, 10, 60, 60))
        self.sidebarToggle.setCursor(QCursor(Qt.PointingHandCursor))
        self.sidebarToggle.setStyleSheet(u"background-color: #000;\n"
"border-radius: 5px;\n"
"")
"color: #fff;\n"
"font-weight: 800;\n"
"font-size: 16pt;"
        self.navTitle.setTextFormat(Qt.AutoText)
        self.navTitle.setAlignment(Qt.AlignCenter)
        self.extras = QWidget(self.garudaContainer)
        self.extras.setObjectName(u"extras")
        self.extras.setGeometry(QRect(20, 410, 211, 171))
        self.extras.setStyleSheet(u"QWidget#extras{\n"
"background-color: transparent;\n"
"border: 2px ridge #00f48e;\n"
"border-radius: 10px;\n"
"}")
        self.IOTSwitch1 = QRadioButton(self.extras)
        self.IOTSwitch1.setObjectName(u"IOTSwitch1")
        self.IOTSwitch1.setGeometry(QRect(20, 10, 181, 30))
        self.IOTSwitch1.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.IOTSwitch1.setAutoExclusive(False)
        self.IOTSwitch2 = QRadioButton(self.extras)
        self.IOTSwitch2.setObjectName(u"IOTSwitch2")
        self.IOTSwitch2.setGeometry(QRect(20, 50, 181, 30))
        self.IOTSwitch2.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.IOTSwitch2.setAutoExclusive(False)
        self.speakSwitch = QRadioButton(self.extras)
        self.speakSwitch.setObjectName(u"speakSwitch")
        self.speakSwitch.setGeometry(QRect(20, 90, 171, 30))
        self.speakSwitch.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.speakSwitch.setAutoExclusive(False)
        self.listenSwitch = QRadioButton(self.extras)
        self.listenSwitch.setObjectName(u"listenSwitch")
        self.listenSwitch.setGeometry(QRect(20, 128, 181, 31))
        self.listenSwitch.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.listenSwitch.setAutoExclusive(False)
        self.showNotification = QLabel(self.garudaContainer)
        self.showNotification.setObjectName(u"showNotification")
        self.showNotification.setGeometry(QRect(400, 100, 230, 40))
        self.showNotification.setStyleSheet(u"background-color: transparent;\n"
"color: #fff;\n"
"font-size: 20px;\n"
"font-weight: 800;")
        self.showNotification.setAlignment(Qt.AlignCenter)
        self.chatDisplay = QWidget(self.garudaContainer)
        self.chatDisplay.setObjectName(u"chatDisplay")
        self.chatDisplay.setGeometry(QRect(10, 89, 1004, 536))
        self.chatDisplay.setStyleSheet(u"QWidget#chatDisplay{\n"
"	background-color: #000;\n"
"	border: 2px ridge #00f48e;\n"
"	border-radius: 10px;\n"
"}")
        self.chatMessages = QTextEdit(self.chatDisplay)
        self.chatMessages.setObjectName(u"chatMessages")
        self.chatMessages.setGeometry(QRect(6, 6, 992, 524))
        font1 = QFont()
        font1.setPointSize(12)
        font1.setBold(False)
        font1.setWeight(50)
        self.chatMessages.setFont(font1)
        self.chatMessages.setStyleSheet(u"background-color: transparent;\n"
"border-radius: 10px;")
        self.chatMessages.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
        self.chatMessages.setReadOnly(True)
        garudaGUI.setCentralWidget(self.garudaContainer)
        self.systemInfo.raise_()
        self.inputTextBox.raise_()
        self.timeAndDate.raise_()
        self.sendButton.raise_()
        self.Logo.raise_()
        self.onlineStatus.raise_()
        self.musicContainer.raise_()
        self.navbar.raise_()
        self.showNotification.raise_()
        self.extras.raise_()
        self.chatDisplay.raise_()

        self.retranslateUi(garudaGUI)

        QMetaObject.connectSlotsByName(garudaGUI)
    # setupUi

    def retranslateUi(self, garudaGUI):
        garudaGUI.setWindowTitle(QCoreApplication.translate("garudaGUI", u" Garuda Virtual Assistant", None))
        self.point1.setText("")
        self.point3.setText("")
        self.uptimeName.setText(QCoreApplication.translate("garudaGUI", u"Uptime", None))
        self.memoryName.setText(QCoreApplication.translate("garudaGUI", u"Memory", None))
        self.storageName.setText(QCoreApplication.translate("garudaGUI", u"Storage", None))
        self.cpuValue.setText(QCoreApplication.translate("garudaGUI", u":  31%", None))
        self.uptimeValue.setText(QCoreApplication.translate("garudaGUI", u":  4000 sec", None))
        self.memoryValue.setText(QCoreApplication.translate("garudaGUI", u":  45%", None))
        self.storageValue.setText(QCoreApplication.translate("garudaGUI", u":  80%", None))
        self.point1_2.setText("")
        self.point1_3.setText("")
        self.cpuName.setText(QCoreApplication.translate("garudaGUI", u"CPU", None))
        self.inputTextBox.setPlainText("")
        self.onlineStatus.setText(QCoreApplication.translate("garudaGUI", u"Status : Online", None))
        self.prevButton.setText("")
        self.nextButton.setText("")
        self.pause.setText("")
        self.sidebarToggle.setText("")
        self.navTitle.setText(QCoreApplication.translate("garudaGUI", u"GARUDA", None))
        self.IOTSwitch1.setText(QCoreApplication.translate("garudaGUI", u"IOT Switch 1", None))
        self.IOTSwitch2.setText(QCoreApplication.translate("garudaGUI", u"IOT Switch 2", None))
        self.speakSwitch.setText(QCoreApplication.translate("garudaGUI", u"Speak Mode", None))
        self.listenSwitch.setText(QCoreApplication.translate("garudaGUI", u"Listening Mode", None))
        self.showNotification.setText(QCoreApplication.translate("garudaGUI", u"Listening...", None))
        self.chatMessages.setHtml(QCoreApplication.translate("garudaGUI", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"right\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt; font-weight:600; color:#ffa500;\">User: Hello, Garuda.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt; font-weight:600; color:#0000ff;\">Garuda: Hi Sir, How can I help you today?</span></p></body></html>", None))
    # retranslateUi

